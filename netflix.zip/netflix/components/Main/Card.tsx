import { View , Image, StyleSheet, ScrollView} from 'react-native'
import React from 'react'
import theme from '@/contants/theme';

export default function Card() {
  return (
    
    <ScrollView horizontal>
      <View style={styles.container}>
          <Image
            source={require("../../assets/images/img1.jpg")}
            style={styles.image}
          />  
          <Image
            source={require("../../assets/images/img2.jpg")}
            style={styles.image}
          />                                
          <Image
            source={require("../../assets/images/img3.jpg")}
            style={styles.image}
          />     
      </View>

      <View >
          <Image
            style={styles.imageUp}
            source={require("../../assets/images/logos_netflix-icon.svg")}
          />
          
          <Image
            style={styles.image}
            source={{ uri: 'https://img.elo7.com.br/product/zoom/2A1A4B7/big-poster-filme-joker-coringa-joaquin-phoenix-tam-90x60-cm-nerd.jpg' }}
            accessibilityLabel="Logo pequeno do React Native"
          />
      </View>
    </ScrollView>             
  )
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    gap: theme.dimension.sm,
    position: 'relative',
    overflow: 'hidden', // Para garantir que a imagem não saia do contêiner
    marginRight:20,
  },
  image: { width: 140, height: 195 },
  text: { color: "#fff", fontSize: 18, fontWeight: "bold" },

  imageUp: {
    width: 30,
    height: 33,
    position: 'absolute', // Posiciona em relação ao contêiner
    zIndex:1
    
  },

});