import { View, Text ,StyleSheet} from 'react-native'
import React from 'react'
import Card from './Card'

export default function index() {
  return (
    <View >
      <Text style={styles.text} >Novidades na Netflix</Text>
      <Card></Card>
    </View>
  )
}

const styles = StyleSheet.create({
  text: { color: "#fff", fontSize: 18, fontWeight: "bold" , marginBottom: 20 },
});