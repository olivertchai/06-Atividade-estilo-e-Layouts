import { View, Text ,StyleSheet} from 'react-native'
import React from 'react';
import Card from './Card';
import theme from '@/contants/theme';


export default function Carrosel() {
  return (
    <View>
      <Card></Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    gap: theme.dimension.sm,
  },
  });